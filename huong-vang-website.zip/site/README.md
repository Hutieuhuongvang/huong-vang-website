# VIFON Hủ Tiếu Hương Vang — Website giới thiệu
Trang web tĩnh (HTML/CSS/JS) chạy trực tiếp trên GitHub Pages.
Cấu trúc: index.html · style.css · script.js · images/product.jpg
